// ProjectTwo.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Gary Hollingsworth
// SNHU CS 300
// Project Two
// Professor Chao Ling

//#includes
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <queue>


using namespace std;


//Main menu
//Called at the start of the program
void menu() {
	cout << "1. Load Data Structure" << endl;
	cout << "2. Print Course List" << endl;
	cout << "3. Print Course." << endl;
	cout << "9. Exit" << endl;
}

//Struct for each course
//Includes courseID,courseName, and a vector of coursePrerequisites
struct Course {
	//Variables
	string courseID;
	string courseName;
	vector<string> coursePrerequisites;

	//Default constructor
	Course() {
		
	}
};

//Tree node structure
struct Node {
	Course course;
	Node* left;
	Node* right;

};

//Creates a new node
Node* CreateNode(Course course) {
	Node* newNode = new Node();
	if (!newNode) {
		cout << "Memory error\n";
		return NULL;
	}
	newNode->course = course;
	newNode->left = newNode->right = NULL;
	return newNode;
}
//Insert element into binary tree
Node* InsertNode(Node* root, Course course) {
	//If tree is empty
	if (root == NULL) {
		root = CreateNode(course);
		return root;
	}
	queue<Node*> q;
	q.push(root);

	while (!q.empty()) {
		Node* temp = q.front();
		q.pop();

		if (temp->left != NULL) {
			q.push(temp->left);
		}
		else {
			temp->left = CreateNode(course);
			return root;
		}
		if (temp->right != NULL)
			q.push(temp->right);
		else {
			temp->right = CreateNode(course);
			return root;
		}
	}
}

// Inorder traversal of tree
void inorder(Node* temp)
{
	//If node is empty. Returns
	if (temp == NULL)
		return;

	inorder(temp->left);
	cout << temp->course.courseID << ' ' << temp->course.courseName << ' '<< endl;
	inorder(temp->right);
}
//Searches for course prequisites for a given courseID
Node* searchCourse(Node* root, const string& courseID) {
	if (root == nullptr || root->course.courseID == courseID) {
		return root;
	}

	// Search in the left subtree
	Node* leftResult = searchCourse(root->left, courseID);
	if (leftResult != nullptr) {
		return leftResult;
	}

	// Search in the right subtree
	return searchCourse(root->right, courseID);
}


//Loads data into a tree
Node* loadData() {
	
	
	ifstream inputFile;

	inputFile.open("CourseInfo.csv");
	//Checks to confirm file did open
	if (!inputFile.is_open()) {
		std::cerr << "Error opening the file!" << std::endl;
		
	}

	//Needed variables including root, line, and vector of courses
	Node* root = nullptr;
	string line;
	vector<Course> courses;
	
	
	//Grabs a line from the csv file,parses data, and calls to insert the structure into a tree
	while (getline(inputFile, line)) {
		istringstream iss(line);
		string token;
		//Creates a course object
		Course course;

		//gets the courseID
		getline(iss, token, ',');
		course.courseID = token;
		
		//Gets the courseName
		getline(iss, token, ',');
		course.courseName = token;

		//Gets the prerequisistes
		while (getline(iss, token, ',')) {
			course.coursePrerequisites.push_back(token);
		}
		root = InsertNode(root, course);
		
		

	}
	
	inputFile.close();
	return root;
	
}



//User choice 2 will call this funtion and print course list
//Prints the course ID and Course Name 
//Outputs in order
void printCourseList(Node* root) {
	
	cout << "Prints course List" << endl;
	//Checks to see if node is empty.
	//If root node is empty tree is empty
	if (root != nullptr) {
		inorder(root);
	}
	else {
		cout << "The tree is empty" << endl;
	}
}

//User choice 3 will call this funtion and print course
// Prompt the user for course number
// Print out course courseID, courseName, coursePrerequisite, and courseNumber
void printCourse(Node* root) {
	

	if (root != nullptr) {
		// Print course IDs and names
		inorder(root);

		// Ask for input
		string inputCourseID;
		cout << "\nEnter a course ID to see prerequisites: ";
		cin >> inputCourseID;

		// Search for the specified courseID in the tree
		Node* courseNode = searchCourse(root, inputCourseID);

		if (courseNode != nullptr) {
			// Print prerequisites for the specified courseID
			cout << "Prerequisites for " << inputCourseID << ": ";
			for (const string& prerequisite : courseNode->course.coursePrerequisites) {
				cout << prerequisite << " ";
			}
			cout << endl;
		}
		else {
			cout << "Course with ID " << inputCourseID << " not found." << endl;
		}
	}
	else {
		cout << "The tree is empty" << endl;
	}
}

//Deletes tree to free up memory
void deallocateTree(Node* root) {
	if (root != nullptr) {
		deallocateTree(root->left);
		deallocateTree(root->right);
		delete root;
	}
}



// Main 
int main()
{
	// Varables
	int choice= 0;
	Node* root = nullptr;
    //Menu
	while (choice != 9) {
		//Menu call
		menu();
		//Get user choice
		cin >> choice;
		//Swich
		switch (choice)
		{
		case 1:
			root = loadData();
			
			break;
		case 2:
			
			printCourseList(root);
			break;
		case 3:
			printCourse(root);
			break;
		case 9:
			deallocateTree(root);
			break;

		default:
			cout << choice << " is not a valid option." << endl;
			break;
		}
	}
	
	
    
}


